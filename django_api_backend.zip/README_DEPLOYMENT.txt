Django File Converter API - InMotion Hosting Deployment Package (Backend Only)
=================================================================================

BEFORE UPLOADING:
1. Edit .env file and update:
   - SECRET_KEY (generate 50-character random string)
   - ALLOWED_HOSTS (replace with your actual domain)
   - CORS_ALLOWED_ORIGINS (replace with your actual domain)

UPLOAD INSTRUCTIONS:
1. Extract this zip file
2. Upload all contents to /home/cinciw5/public_html/
3. SSH into your server and run:
   cd /home/cinciw5/public_html/
   pip install -r requirements.txt
   python manage.py migrate
   python manage.py collectstatic --noinput
   python manage.py createsuperuser

INMOTION PYTHON APP CONFIGURATION:
- Python Version: 3.9 (or highest available)
- Application Root: /home/cinciw5/public_html/
- Application URL: https://yourdomain.com/
- Application Startup File: passenger_wsgi.py
- Application Entry Point: application
- Passenger Log File: /home/cinciw5/logs/passenger.log

TEST URLS AFTER DEPLOYMENT:
- Simple Interface: https://yourdomain.com/simple/
- Admin Panel: https://yourdomain.com/admin/
- API Documentation: https://yourdomain.com/swagger/

PDF to TXT conversion will work immediately!
This package contains ONLY the Django backend - no React frontend included.
