from django.apps import AppConfig


class StorageIntegrationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'storage_integrations'
